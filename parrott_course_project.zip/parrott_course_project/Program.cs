﻿//Tiffany Parrott
//Course Project 3.7
//1-1-24

using System;

public class Program
{
    // Properties
    public static InventoryManager Inventory { get; set; } = new InventoryManager();

    // Methods
    public static void Main()
    {
        DisplayMenu();
        // Main program logic here
    }

    public static void DisplayMenu()
    {
        // Menu display logic here
    }
}
