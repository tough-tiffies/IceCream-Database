//Tiffany Parrott
//Course Project 3.7
//1-1-24

public class Employee
{
    // Properties
    public string EmployeeId { get; set; }
    public string Name { get; set; }

    // Constructor
    public Employee(string employeeId, string name)
    {
        EmployeeId = employeeId;
        Name = name;
    }

    // Methods
    public void PlaceOrder(IceCreamItem item, int quantity)
    {
        // Logic to place an order for supplies
        // This method could interact with the InventoryManager or another class responsible for managing orders.
    }

    public void TakeOrder(Customer customer, IceCreamItem item, int quantity)
    {
        // Logic to take a customer's order
        // This method could interact with the SalesRecord or another class responsible for managing sales.
    }
}
