//Tiffany Parrott
//Course Project 3.7
//1-1-24

using System;

public class IceCreamItem
{
    // Properties
    public string Flavor { get; set; }
    public int Quantity { get; set; }
    public string Size { get; set; }
    public decimal SalePrice { get; set; }
    public decimal TotalPurchase { get; private set; }

    // Methods
    public void CalculateTotalPurchase()
    {
        TotalPurchase = Quantity * SalePrice;
    }

    public Employee OrderedBy { get; set; }

    public void UpdateInventory(int soldQuantity)
    {
        if (soldQuantity <= Quantity)
        {
            Quantity -= soldQuantity;
        }
        else
        {
            Console.WriteLine("Error: Insufficient inventory.");
        }
    }

    public override string ToString()
    {
        return $"{Flavor} - {Size} - Quantity: {Quantity} - Price: {SalePrice:C} - Total Purchase: {TotalPurchase:C}";
    }
}
