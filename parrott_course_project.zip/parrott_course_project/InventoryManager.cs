//Tiffany Parrott
//Course Project 3.7
//1-1-24

using System;
using System.Collections.Generic;

public class InventoryManager
{
    // Properties
    public List<IceCreamItem> IceCreamInventory { get; set; } = new List<IceCreamItem>();

    // Methods
    public void ReplenishStock(IceCreamItem newItem)
    {
        IceCreamInventory.Add(newItem);
    }

    public void SellIceCream(IceCreamItem item, int quantity)
    {
        var inventoryItem = IceCreamInventory.Find(i => i.Flavor == item.Flavor && i.Size == item.Size);

        if (inventoryItem != null)
        {
            inventoryItem.UpdateInventory(quantity);
        }
        else
        {
            Console.WriteLine("Error: Item not found in inventory.");
        }
    }

    public void ReplenishStock(IceCreamItem newItem, Employee orderedBy)
    {
        newItem.OrderedBy = orderedBy;
        IceCreamInventory.Add(newItem);
    }
    
    public void GenerateInventoryReport()
    {
        Console.WriteLine("Current Inventory Report:");
        foreach (var item in IceCreamInventory)
        {
            Console.WriteLine(item.ToString());
        }
    }
}
