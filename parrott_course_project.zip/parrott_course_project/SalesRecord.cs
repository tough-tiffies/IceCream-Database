//Tiffany Parrott
//Course Project 3.7
//1-1-24

using System;
using System.Collections.Generic;

public class SalesRecord
{
    // Properties
    public DateTime SaleDate { get; set; }
    public Employee TakenBy { get; set; }
    public List<IceCreamItem> SoldItems { get; set; } = new List<IceCreamItem>();
    public decimal TotalSaleAmount { get; private set; }

    // Methods
    public void CalculateTotalSaleAmount()
    {
        TotalSaleAmount = 0;
        foreach (var item in SoldItems)
        {
            TotalSaleAmount += item.TotalPurchase;
        }
    }


    public void PrintReceipt()
    {
        Console.WriteLine($"Sale Date: {SaleDate}");
        foreach (var item in SoldItems)
        {
            Console.WriteLine(item.ToString());
        }
        Console.WriteLine($"Total Sale Amount: {TotalSaleAmount:C}");
    }
}
