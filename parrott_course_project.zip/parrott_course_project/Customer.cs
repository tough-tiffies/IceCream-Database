//Tiffany Parrott
//Course Project 3.7
//1-1-24

public class Customer
{
    // Properties
    public string CustomerId { get; set; }
    public string Name { get; set; }

    // Constructor
    public Customer(string customerId, string name)
    {
        CustomerId = customerId;
        Name = name;
    }

    // Methods
    public void PlaceOrder(IceCreamItem item, int quantity)
    {
        // Logic to place an order as a customer
        // This method could interact with the InventoryManager or another class responsible for managing customer orders.
    }
}
